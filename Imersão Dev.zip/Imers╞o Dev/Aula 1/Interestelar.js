var anosLuz = prompt("Total de anos Luz: ");
var valorAnosLuz = 9.51 * 10 ** 12;
var nomeDaPessoa = "viajante";
var distanciaKm = anosLuz * valorAnosLuz;
//distanciaKm = distanciaKm.toFixed(6);
alert(
    "Olá viajante, a distância percorrida foi de " + distanciaKm + " quilômetros"
);